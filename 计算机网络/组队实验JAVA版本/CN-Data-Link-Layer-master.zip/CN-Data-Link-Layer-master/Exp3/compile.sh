# Compile server and client classes
javac UDPServer.java
javac UDPClient.java
# Run UDP server, listening at port 8888
java UDPServer