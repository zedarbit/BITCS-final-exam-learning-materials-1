#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int args,char *argv[])
{
    cps();
    exit();
}
