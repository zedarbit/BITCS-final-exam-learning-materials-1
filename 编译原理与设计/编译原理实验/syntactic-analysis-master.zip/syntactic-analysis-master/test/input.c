int main() {
  int a = 1;
  a = a * 2;
  if (a) {
    a = a / 1;
  } else {
    a = a - 1;
  }
  return a;
}